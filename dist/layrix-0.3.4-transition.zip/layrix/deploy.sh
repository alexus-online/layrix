#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/.env"

EXCLUDE=(
    ".env"
    "deploy.sh"
    ".git"
    ".gitignore"
    ".claude"
    ".vscode"
    ".DS_Store"
    "tmp"
    "node_modules"
    "tests"
    "scripts"
    "playwright.config.js"
    "package.json"
    "package-lock.json"
    "test-results"
    "website-quality-check"
)

echo "Deploying elementor-core-framework to $FTP_HOST ..."

upload_file() {
    local local_file="$1"
    local rel_path="${local_file#$SCRIPT_DIR/}"
    local remote_path="$FTP_PLUGIN_PATH/$rel_path"
    local remote_dir=$(dirname "$remote_path")

    # Create remote directory (ignore errors if exists)
    curl -s --ftp-ssl --ftp-create-dirs \
        -u "$FTP_USER:$FTP_PASS" \
        --insecure \
        --upload-file "$local_file" \
        "ftp://$FTP_HOST$remote_path" 2>/dev/null || \
    curl -s \
        -u "$FTP_USER:$FTP_PASS" \
        --upload-file "$local_file" \
        "ftp://$FTP_HOST$remote_path"
}

is_excluded() {
    local file="$1"
    for excl in "${EXCLUDE[@]}"; do
        if [[ "$file" == *"$excl"* ]]; then
            return 0
        fi
    done
    return 1
}

count=0
while IFS= read -r -d '' file; do
    if ! is_excluded "$file"; then
        rel="${file#$SCRIPT_DIR/}"
        echo "  uploading: $rel"
        upload_file "$file"
        ((count++))
    fi
done < <(find "$SCRIPT_DIR" -type f -print0)

echo ""
echo "Fertig! $count Dateien hochgeladen."
